/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.myname;

/**
 *
 * @author lsphe
 */
public class Myname {

    public static void main(String[] args) {
        // Row 1
        System.out.println(" *****   *****   *   *   *****   *****     *     *   *   *       ***** ");

        // Row 2
        System.out.println(" *       *   *   *   *   *       *        ***    *   *   *       *     ");

        // Row 3
        System.out.println(" *****   *****   *****   *****   *****     *     *****   *       ***** ");

        // Row 4
        System.out.println("     *   *       *   *   *           *     *     *   *   *       *     ");

        // Row 5
        System.out.println(" *****   *       *   *   *****   *****   *****   *   *   *****   ***** ");
    }
}
